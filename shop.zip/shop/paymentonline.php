<?php include 'inc/header.php';?>


<div class="shopping">
	<div class="shopleft">
		<a href="https://esewa.com.np/"> <img src="images/es2.png" alt="" /></a>
			</div>
		<div class="shopright">
			<a href="https://web.khalti.com/"> <img src="images/k1.png" alt="" /></a>
				</div>
				</div>
    	</div>  	



<?php include 'inc/footer.php';?>